import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, Calendar, User, ExternalLink } from 'lucide-react';
import { fetchArticleById } from '../utils/api';
import { Article } from '../types';
import { formatDateTime } from '../utils/formatters';

const ArticlePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [article, setArticle] = useState<Article | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadArticle = async () => {
      if (!id) return;
      
      try {
        setLoading(true);
        const articleData = await fetchArticleById(id);
        
        if (articleData) {
          setArticle(articleData);
          // Update page title
          document.title = `${articleData.title} | AutoBlogAI`;
        }
      } catch (error) {
        console.error('Failed to load article:', error);
      } finally {
        setLoading(false);
      }
    };

    loadArticle();
    
    // Reset title on unmount
    return () => {
      const defaultTitle = document.querySelector('title[data-default]')?.textContent;
      if (defaultTitle) document.title = defaultTitle;
    };
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 pt-32 pb-12">
        <div className="animate-pulse">
          <div className="h-8 w-48 bg-gray-300 dark:bg-gray-700 rounded mb-8"></div>
          <div className="h-12 w-full bg-gray-300 dark:bg-gray-700 rounded mb-4"></div>
          <div className="flex space-x-4 mb-8">
            <div className="h-4 w-24 bg-gray-300 dark:bg-gray-700 rounded"></div>
            <div className="h-4 w-32 bg-gray-300 dark:bg-gray-700 rounded"></div>
          </div>
          <div className="h-64 w-full bg-gray-300 dark:bg-gray-700 rounded mb-8"></div>
          <div className="space-y-4">
            <div className="h-4 w-full bg-gray-300 dark:bg-gray-700 rounded"></div>
            <div className="h-4 w-full bg-gray-300 dark:bg-gray-700 rounded"></div>
            <div className="h-4 w-3/4 bg-gray-300 dark:bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    );
  }
  
  if (!article) {
    return (
      <div className="max-w-4xl mx-auto px-4 pt-32 pb-12 text-center">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Article Not Found</h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          The article you're looking for doesn't exist or has been removed.
        </p>
        <Link 
          to="/" 
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
        >
          <ChevronLeft size={16} className="mr-2" />
          <span>Back to Homepage</span>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 pt-32 pb-12">
      {/* Back button */}
      <Link 
        to="/" 
        className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:underline mb-8"
      >
        <ChevronLeft size={16} className="mr-1" />
        <span>Back to articles</span>
      </Link>
      
      {/* Article header */}
      <header>
        <div className="mb-4">
          <Link 
            to={`/category/${article.category}`}
            className="inline-block px-3 py-1 text-xs font-medium rounded bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-400"
          >
            {article.category}
          </Link>
        </div>
        
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
          {article.title}
        </h1>
        
        <div className="flex flex-wrap items-center text-sm text-gray-600 dark:text-gray-400 mb-8">
          <div className="flex items-center mr-6 mb-2">
            <Calendar size={16} className="mr-2" />
            <span>{formatDateTime(article.date)}</span>
          </div>
          <div className="flex items-center mb-2">
            <User size={16} className="mr-2" />
            <span>Source: {article.source}</span>
          </div>
        </div>
      </header>
      
      {/* Featured image */}
      <div className="mb-8 rounded-lg overflow-hidden">
        <img 
          src={article.image} 
          alt={article.title} 
          className="w-full h-auto object-cover" 
        />
      </div>
      
      {/* Article content */}
      <div 
        className="prose prose-lg max-w-none dark:prose-invert prose-headings:text-gray-900 dark:prose-headings:text-white prose-p:text-gray-700 dark:prose-p:text-gray-300"
        dangerouslySetInnerHTML={{ __html: article.content }}
      />
      
      {/* Article footer */}
      <div className="mt-12 pt-6 border-t border-gray-200 dark:border-gray-800">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div className="text-sm text-gray-600 dark:text-gray-400 mb-4 sm:mb-0">
            Original source: {article.source}
          </div>
          <a 
            href="#"
            className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:underline"
          >
            <span>View original article</span>
            <ExternalLink size={16} className="ml-1" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default ArticlePage;