import React, { useState, useEffect } from 'react';
import { ExternalLink } from 'lucide-react';
import ArticleGrid from '../components/ArticleGrid';
import AutoRefresh from '../components/AutoRefresh';
import { fetchArticles, fetchCategories } from '../utils/api';
import { Article, Category } from '../types';

const HomePage: React.FC = () => {
  const [articles, setArticles] = useState<Article[]>([]);
  const [featuredArticle, setFeaturedArticle] = useState<Article | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('');
  const [loading, setLoading] = useState(true);

  const loadArticles = async () => {
    try {
      setLoading(true);
      const articlesData = await fetchArticles(activeCategory || undefined);
      
      if (articlesData.length > 0 && !activeCategory) {
        // Set the newest article as featured when on the homepage
        setFeaturedArticle(articlesData[0]);
        setArticles(articlesData.slice(1));
      } else {
        setFeaturedArticle(null);
        setArticles(articlesData);
      }
    } catch (error) {
      console.error('Failed to load articles:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const loadCategories = async () => {
      try {
        const categoriesData = await fetchCategories();
        setCategories(categoriesData);
      } catch (error) {
        console.error('Failed to load categories:', error);
      }
    };

    loadCategories();
  }, []);

  useEffect(() => {
    loadArticles();
  }, [activeCategory]);

  const handleCategoryFilter = (categorySlug: string) => {
    setActiveCategory(categorySlug === activeCategory ? '' : categorySlug);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 pt-24 pb-12">
      {/* Hero Section */}
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
          {activeCategory 
            ? `${categories.find(c => c.slug === activeCategory)?.name || activeCategory} Articles` 
            : 'Latest Articles'}
        </h1>
        <AutoRefresh onRefresh={loadArticles} />
      </div>

      {/* Category Filters */}
      <div className="mb-8">
        <div className="flex overflow-x-auto pb-2 space-x-2">
          <button
            onClick={() => setActiveCategory('')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              activeCategory === ''
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 text-gray-800 hover:bg-gray-300 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            All
          </button>
          
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => handleCategoryFilter(category.slug)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                activeCategory === category.slug
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-800 hover:bg-gray-300 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Article */}
      {featuredArticle && !activeCategory && (
        <div className="mb-12 bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-lg">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="order-2 md:order-1 p-6 flex flex-col justify-center">
              <span className="inline-block px-3 py-1 text-xs font-medium rounded bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-400 mb-4">
                {featuredArticle.category}
              </span>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-4">
                {featuredArticle.title}
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6 line-clamp-3">
                {featuredArticle.summary}
              </p>
              <div className="mt-auto">
                <a 
                  href={`/article/${featuredArticle.id}`}
                  className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                >
                  <span>Read article</span>
                  <ExternalLink size={16} className="ml-2" />
                </a>
              </div>
            </div>
            <div className="order-1 md:order-2 h-64 md:h-auto">
              <img 
                src={featuredArticle.image} 
                alt={featuredArticle.title} 
                className="w-full h-full object-cover" 
              />
            </div>
          </div>
        </div>
      )}

      {/* Article Grid */}
      <ArticleGrid articles={articles} loading={loading} />
    </div>
  );
};

export default HomePage;