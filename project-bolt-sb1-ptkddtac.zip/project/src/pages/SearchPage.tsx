import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Search as SearchIcon } from 'lucide-react';
import ArticleGrid from '../components/ArticleGrid';
import { searchArticles } from '../utils/api';
import { Article } from '../types';

const SearchPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const query = new URLSearchParams(location.search).get('q') || '';
  
  const [searchQuery, setSearchQuery] = useState(query);
  const [results, setResults] = useState<Article[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    if (query) {
      performSearch(query);
    }
  }, [query]);

  const performSearch = async (searchTerm: string) => {
    if (!searchTerm.trim()) return;
    
    try {
      setLoading(true);
      setSearched(true);
      
      const searchResults = await searchArticles(searchTerm);
      setResults(searchResults);
      
      // Update page title
      document.title = `Search: ${searchTerm} | AutoBlogAI`;
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      performSearch(searchQuery);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 pt-32 pb-12">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
        Search Articles
      </h1>
      
      <form onSubmit={handleSearchSubmit} className="mb-12">
        <div className="flex w-full max-w-3xl mx-auto">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for articles..."
            className="flex-grow px-4 py-3 rounded-l-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:border-gray-700 dark:text-white"
          />
          <button
            type="submit"
            className="px-6 py-3 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700 transition-colors flex items-center"
          >
            <SearchIcon size={20} className="mr-2" />
            <span>Search</span>
          </button>
        </div>
      </form>
      
      {searched && (
        <>
          <div className="mb-6">
            {query && (
              <h2 className="text-xl text-gray-700 dark:text-gray-300">
                {loading ? 'Searching...' : (
                  results.length > 0 
                    ? `Found ${results.length} results for "${query}"`
                    : `No results found for "${query}"`
                )}
              </h2>
            )}
          </div>

          <ArticleGrid articles={results} loading={loading} />
          
          {results.length === 0 && !loading && (
            <div className="mt-8 text-center">
              <p className="text-gray-600 dark:text-gray-400">
                Try different keywords or check back later as our content is constantly updating.
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default SearchPage;