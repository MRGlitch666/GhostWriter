import React from 'react';
import { Server, Cpu, Rss, RefreshCw, FileJson, Bot } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 pt-32 pb-12">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
        About AutoBlogAI
      </h1>
      
      <div className="prose prose-lg max-w-none dark:prose-invert mb-12">
        <p>
          AutoBlogAI is a fully automated content platform that runs 24/7 without human intervention.
          Our system automatically fetches articles from curated RSS feeds, rewrites them using advanced AI technology,
          and publishes them on this site in real-time.
        </p>
        <p>
          The entire process is automated from start to finish, creating a truly hands-off publishing system
          that continuously updates with fresh, unique content.
        </p>
      </div>
      
      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
        How AutoBlogAI Works
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <div className="flex items-center mb-4">
            <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-full mr-4">
              <Rss className="text-blue-600 dark:text-blue-400" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
              1. RSS Feed Fetching
            </h3>
          </div>
          <p className="text-gray-700 dark:text-gray-300">
            Our system monitors multiple RSS feeds from reputable sources across various categories.
            When new content is published, it's automatically detected and fetched by our system.
          </p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <div className="flex items-center mb-4">
            <div className="bg-teal-100 dark:bg-teal-900/30 p-3 rounded-full mr-4">
              <Server className="text-teal-600 dark:text-teal-400" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
              2. Make.com Integration
            </h3>
          </div>
          <p className="text-gray-700 dark:text-gray-300">
            Make.com's automation platform acts as the central nervous system, orchestrating the entire workflow
            from content discovery to publication without any manual intervention.
          </p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <div className="flex items-center mb-4">
            <div className="bg-purple-100 dark:bg-purple-900/30 p-3 rounded-full mr-4">
              <Bot className="text-purple-600 dark:text-purple-400" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
              3. AI Content Rewriting
            </h3>
          </div>
          <p className="text-gray-700 dark:text-gray-300">
            Google's Gemini API analyzes the original content and creates completely unique, rewritten articles
            that maintain the core information while presenting it in an original format.
          </p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <div className="flex items-center mb-4">
            <div className="bg-green-100 dark:bg-green-900/30 p-3 rounded-full mr-4">
              <FileJson className="text-green-600 dark:text-green-400" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
              4. JSON File Creation
            </h3>
          </div>
          <p className="text-gray-700 dark:text-gray-300">
            The rewritten content is structured and stored as JSON files on our server,
            making it easy to manage and display the content dynamically on the website.
          </p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <div className="flex items-center mb-4">
            <div className="bg-orange-100 dark:bg-orange-900/30 p-3 rounded-full mr-4">
              <Cpu className="text-orange-600 dark:text-orange-400" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
              5. Dynamic Content Display
            </h3>
          </div>
          <p className="text-gray-700 dark:text-gray-300">
            Our website reads the JSON files and displays the content in a clean, organized format,
            automatically categorizing and organizing the articles by topic and publication date.
          </p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <div className="flex items-center mb-4">
            <div className="bg-red-100 dark:bg-red-900/30 p-3 rounded-full mr-4">
              <RefreshCw className="text-red-600 dark:text-red-400" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
              6. Continuous Updates
            </h3>
          </div>
          <p className="text-gray-700 dark:text-gray-300">
            The system runs continuously, checking for new content and updating the website in real-time.
            No human intervention is required at any point in the process.
          </p>
        </div>
      </div>
      
      <div className="bg-gray-100 dark:bg-gray-800 p-8 rounded-lg">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
          Why AutoBlogAI?
        </h2>
        <ul className="list-disc pl-6 text-gray-700 dark:text-gray-300 space-y-2">
          <li>Fully automated content generation without human intervention</li>
          <li>Always fresh, unique content that's SEO-friendly</li>
          <li>Cost-effective content production at scale</li>
          <li>24/7 operation with automatic updates</li>
          <li>Diverse content across multiple categories</li>
          <li>No need for content writers, editors, or manual publishing</li>
        </ul>
      </div>
    </div>
  );
};

export default AboutPage;