export interface Article {
  id: string;
  title: string;
  content: string;
  summary: string;
  image: string;
  date: string;
  source: string;
  category: string;
  url: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
}

export interface FeedSource {
  id: string;
  name: string;
  url: string;
  category: string;
}