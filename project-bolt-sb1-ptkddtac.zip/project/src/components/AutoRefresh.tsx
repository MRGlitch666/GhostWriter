import React, { useState, useEffect } from 'react';
import { RefreshCw } from 'lucide-react';

interface AutoRefreshProps {
  onRefresh: () => void;
  interval?: number; // in seconds
  enabled?: boolean;
}

const AutoRefresh: React.FC<AutoRefreshProps> = ({ 
  onRefresh, 
  interval = 60, 
  enabled = true 
}) => {
  const [remainingTime, setRemainingTime] = useState(interval);
  const [isAutoRefreshEnabled, setIsAutoRefreshEnabled] = useState(enabled);
  const [isManualRefreshing, setIsManualRefreshing] = useState(false);

  useEffect(() => {
    let timer: number | undefined;
    
    if (isAutoRefreshEnabled) {
      setRemainingTime(interval);
      
      timer = window.setInterval(() => {
        setRemainingTime(prev => {
          if (prev <= 1) {
            handleRefresh();
            return interval;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isAutoRefreshEnabled, interval]);

  const handleRefresh = () => {
    setIsManualRefreshing(true);
    onRefresh();
    setTimeout(() => setIsManualRefreshing(false), 1000);
  };

  const toggleAutoRefresh = () => {
    setIsAutoRefreshEnabled(!isAutoRefreshEnabled);
  };

  return (
    <div className="flex items-center space-x-3 text-sm">
      <button
        onClick={handleRefresh}
        className="flex items-center space-x-1 text-gray-600 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white transition-colors"
        disabled={isManualRefreshing}
        aria-label="Refresh content"
      >
        <RefreshCw 
          size={16} 
          className={`${isManualRefreshing ? 'animate-spin' : ''}`} 
        />
        <span>Refresh</span>
      </button>
      
      <div className="flex items-center">
        <label htmlFor="auto-refresh" className="text-gray-600 dark:text-gray-400 mr-2">
          Auto-refresh
        </label>
        <div className="relative inline-block w-10 mr-2 align-middle select-none">
          <input
            type="checkbox"
            id="auto-refresh"
            name="auto-refresh"
            checked={isAutoRefreshEnabled}
            onChange={toggleAutoRefresh}
            className="sr-only"
          />
          <div className="block bg-gray-300 dark:bg-gray-700 w-10 h-6 rounded-full"></div>
          <div 
            className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${
              isAutoRefreshEnabled ? 'transform translate-x-4' : ''
            }`}
          ></div>
        </div>
      </div>
      
      {isAutoRefreshEnabled && (
        <span className="text-gray-500 dark:text-gray-400">
          {`${remainingTime}s`}
        </span>
      )}
    </div>
  );
};

export default AutoRefresh;