import React from 'react';
import { Link } from 'react-router-dom';
import { Rss, Mail, Github, Twitter, Ghost, Pen } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-100 dark:bg-gray-900 mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center space-x-2 text-2xl font-bold">
              <div className="relative">
                <Ghost className="w-8 h-8 text-purple-600 dark:text-purple-400" />
                <Pen className="w-4 h-4 absolute bottom-0 right-0 text-teal-500 dark:text-teal-400" />
              </div>
              <span className="text-purple-900 dark:text-white">
                Ghost<span className="text-teal-500">Writer</span>
              </span>
            </Link>
            <p className="mt-4 text-gray-600 dark:text-gray-400 max-w-md">
              An AI-powered, fully automated blog that updates itself with unique, rewritten articles from 
              selected sources via RSS feeds. No human intervention required.
            </p>
            <div className="flex space-x-4 mt-6">
              <a 
                href="#" 
                className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={20} />
              </a>
              <a 
                href="#" 
                className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                aria-label="GitHub"
              >
                <Github size={20} />
              </a>
              <a 
                href="mailto:contact@ghostwriter.com" 
                className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                aria-label="Email"
              >
                <Mail size={20} />
              </a>
              <a 
                href="/rss" 
                className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                aria-label="RSS Feed"
              >
                <Rss size={20} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/category/technology" 
                  className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                >
                  Technology
                </Link>
              </li>
              <li>
                <Link 
                  to="/category/business" 
                  className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                >
                  Business
                </Link>
              </li>
              <li>
                <Link 
                  to="/category/science" 
                  className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                >
                  Science
                </Link>
              </li>
              <li>
                <Link 
                  to="/category/health" 
                  className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                >
                  Health
                </Link>
              </li>
              <li>
                <Link 
                  to="/category/entertainment" 
                  className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                >
                  Entertainment
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/about" 
                  className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                >
                  About
                </Link>
              </li>
              <li>
                <Link 
                  to="/privacy-policy" 
                  className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                >
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link 
                  to="/terms" 
                  className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                >
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link 
                  to="/contact" 
                  className="text-gray-600 hover:text-purple-600 dark:text-gray-400 dark:hover:text-white transition-colors"
                >
                  Contact
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-300 dark:border-gray-700 mt-8 pt-8 text-sm text-gray-500 dark:text-gray-400">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p>© {currentYear} GhostWriter. All rights reserved.</p>
            <p className="mt-2 md:mt-0">
              Powered by <span className="text-purple-900 dark:text-purple-400 font-medium">Gemini AI</span> and <span className="text-teal-600 dark:text-teal-400 font-medium">Make.com</span>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;