import React from 'react';
import { Link } from 'react-router-dom';
import { Article } from '../types';
import { formatDate } from '../utils/formatters';

interface ArticleCardProps {
  article: Article;
}

const ArticleCard: React.FC<ArticleCardProps> = ({ article }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
      <Link to={`/article/${article.id}`}>
        <div className="h-48 overflow-hidden">
          <img 
            src={article.image} 
            alt={article.title} 
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
          />
        </div>
      </Link>
      <div className="p-5">
        <div className="flex items-center mb-2">
          <span className="text-xs font-medium uppercase tracking-wider text-teal-600 dark:text-teal-400 bg-teal-100 dark:bg-teal-900/30 px-2 py-1 rounded">
            {article.category}
          </span>
          <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">
            {formatDate(article.date)}
          </span>
        </div>
        <Link to={`/article/${article.id}`}>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
            {article.title}
          </h2>
        </Link>
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-3">
          {article.summary}
        </p>
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500 dark:text-gray-400">
            Source: {article.source}
          </span>
          <Link 
            to={`/article/${article.id}`} 
            className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline"
          >
            Read more
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ArticleCard;