import React from 'react';
import { Article } from '../types';
import ArticleCard from './ArticleCard';

interface ArticleGridProps {
  articles: Article[];
  loading?: boolean;
}

const ArticleGrid: React.FC<ArticleGridProps> = ({ articles, loading = false }) => {
  // Skeleton loader for articles while they're loading
  const renderSkeletons = () => {
    return Array(6)
      .fill(0)
      .map((_, index) => (
        <div key={`skeleton-${index}`} className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow animate-pulse">
          <div className="h-48 bg-gray-300 dark:bg-gray-700"></div>
          <div className="p-5">
            <div className="flex items-center mb-2">
              <div className="h-4 w-16 bg-gray-300 dark:bg-gray-700 rounded"></div>
              <div className="h-4 w-24 bg-gray-300 dark:bg-gray-700 rounded ml-auto"></div>
            </div>
            <div className="h-6 w-3/4 bg-gray-300 dark:bg-gray-700 rounded mb-2"></div>
            <div className="h-4 w-full bg-gray-300 dark:bg-gray-700 rounded mb-1"></div>
            <div className="h-4 w-full bg-gray-300 dark:bg-gray-700 rounded mb-1"></div>
            <div className="h-4 w-2/3 bg-gray-300 dark:bg-gray-700 rounded mb-4"></div>
            <div className="flex items-center justify-between">
              <div className="h-3 w-20 bg-gray-300 dark:bg-gray-700 rounded"></div>
              <div className="h-3 w-16 bg-gray-300 dark:bg-gray-700 rounded"></div>
            </div>
          </div>
        </div>
      ));
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {renderSkeletons()}
      </div>
    );
  }

  if (articles.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-600 dark:text-gray-400 text-lg">No articles found</p>
        <p className="text-gray-500 dark:text-gray-500 text-sm mt-2">
          Try adjusting your search or check back later for new content
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {articles.map((article) => (
        <ArticleCard key={article.id} article={article} />
      ))}
    </div>
  );
};

export default ArticleGrid;