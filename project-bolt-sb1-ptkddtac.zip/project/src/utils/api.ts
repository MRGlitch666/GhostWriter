import { Article, Category, FeedSource } from '../types';

// Simulated JSON data that would normally come from the server
// In a real implementation, this would fetch from /posts/ directory

const categories: Category[] = [
  { id: '1', name: 'Technology', slug: 'technology' },
  { id: '2', name: 'Business', slug: 'business' },
  { id: '3', name: 'Science', slug: 'science' },
  { id: '4', name: 'Health', slug: 'health' },
  { id: '5', name: 'Entertainment', slug: 'entertainment' },
];

const feedSources: FeedSource[] = [
  { id: '1', name: 'TechCrunch', url: 'https://techcrunch.com/feed/', category: 'technology' },
  { id: '2', name: 'Business Insider', url: 'https://businessinsider.com/rss', category: 'business' },
  { id: '3', name: 'Science Daily', url: 'https://sciencedaily.com/rss', category: 'science' },
  { id: '4', name: 'Health News', url: 'https://health.com/feed', category: 'health' },
  { id: '5', name: 'Entertainment Weekly', url: 'https://ew.com/feed', category: 'entertainment' },
];

// This simulates the articles that would be generated from RSS and AI rewriting
const articles: Article[] = [
  {
    id: '1',
    title: 'The Future of AI in Content Creation',
    content: `<p>Artificial intelligence has revolutionized how content is created, curated, and consumed online. With recent advancements in large language models, the quality of AI-generated content has improved dramatically.</p>
    <p>Companies across industries are increasingly turning to AI-powered solutions to automate content production, enabling them to scale their online presence without proportional increases in human resources.</p>
    <p>The technology behind these systems involves sophisticated natural language processing algorithms that can understand context, maintain coherence, and generate text that's nearly indistinguishable from human-written content.</p>
    <p>As these technologies continue to evolve, we're likely to see even more seamless integration of AI in content workflows, raising important questions about the future of creative professions and the economics of content production.</p>`,
    summary: 'How artificial intelligence is transforming the content creation landscape with advanced language models.',
    image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg',
    date: '2023-05-15T14:30:00Z',
    source: 'TechCrunch',
    category: 'technology',
    url: '/article/1',
  },
  {
    id: '2',
    title: 'Global Markets Respond to Economic Policy Shifts',
    content: `<p>Financial markets worldwide showed significant volatility today as central banks announced coordinated policy changes aimed at controlling inflation while supporting economic growth.</p>
    <p>The Federal Reserve's decision to adjust interest rates triggered a cascade of responses from other major economies, with European and Asian markets experiencing notable fluctuations throughout the trading day.</p>
    <p>Analysts point to several underlying factors contributing to the market reaction, including supply chain disruptions, energy price instability, and shifting consumer spending patterns in the post-pandemic economic landscape.</p>
    <p>Investors are advised to maintain diversified portfolios as markets adapt to these policy changes, with particular attention to sectors that historically demonstrate resilience during periods of monetary tightening.</p>`,
    summary: 'How global financial markets are responding to coordinated central bank policy changes.',
    image: 'https://images.pexels.com/photos/6801874/pexels-photo-6801874.jpeg',
    date: '2023-05-14T09:15:00Z',
    source: 'Business Insider',
    category: 'business',
    url: '/article/2',
  },
  {
    id: '3',
    title: 'Breakthrough in Quantum Computing Promises New Capabilities',
    content: `<p>Scientists at the Quantum Research Institute have achieved a significant milestone in quantum computing stability, potentially bringing practical quantum computing applications closer to reality.</p>
    <p>The research team successfully maintained quantum coherence for a record-breaking duration, addressing one of the most persistent challenges in quantum computing development.</p>
    <p>This breakthrough could accelerate advancements in fields ranging from cryptography and materials science to drug discovery and climate modeling, where quantum computing's unique capabilities offer exponential improvements over classical computing approaches.</p>
    <p>Industry leaders in technology and computing have already expressed interest in incorporating these findings into their quantum research initiatives, potentially accelerating the timeline for commercially viable quantum computing solutions.</p>`,
    summary: 'Recent advances in quantum coherence promise to accelerate the development of practical quantum computing applications.',
    image: 'https://images.pexels.com/photos/373543/pexels-photo-373543.jpeg',
    date: '2023-05-13T11:45:00Z',
    source: 'Science Daily',
    category: 'science',
    url: '/article/3',
  },
  {
    id: '4',
    title: 'New Research Reveals Benefits of Intermittent Fasting',
    content: `<p>A comprehensive study published in the Journal of Nutrition and Metabolism has provided new insights into the health benefits of intermittent fasting beyond weight management.</p>
    <p>Researchers observed significant improvements in metabolic markers, inflammatory responses, and cellular repair mechanisms among participants who followed various intermittent fasting protocols over a six-month period.</p>
    <p>Particularly noteworthy were the improvements in insulin sensitivity and autophagy—the body's natural process for removing damaged cells and regenerating newer, healthier cells.</p>
    <p>Healthcare professionals emphasize that while the results are promising, intermittent fasting approaches should be tailored to individual health conditions and lifestyle factors, with appropriate medical supervision for those with pre-existing health concerns.</p>`,
    summary: 'Recent research highlights multiple health benefits of intermittent fasting beyond weight management.',
    image: 'https://images.pexels.com/photos/3872367/pexels-photo-3872367.jpeg',
    date: '2023-05-12T16:20:00Z',
    source: 'Health News',
    category: 'health',
    url: '/article/4',
  },
  {
    id: '5',
    title: 'Streaming Platforms Announce Major Original Content Investments',
    content: `<p>Leading streaming services have collectively announced over $30 billion in new content production investments for the coming year, signaling an intensification of competition in the digital entertainment space.</p>
    <p>These investments will fund hundreds of new original series, films, and documentaries as streaming platforms seek to differentiate their offerings and attract subscribers in an increasingly crowded marketplace.</p>
    <p>Industry analysts note that this content arms race represents a significant shift in entertainment industry economics, with traditional studio systems and theatrical release models facing continued disruption.</p>
    <p>Content creators, directors, and production companies are experiencing unprecedented demand for original concepts, though concerns about sustainable business models and content oversaturation remain prominent in industry discussions.</p>`,
    summary: 'Major streaming platforms announce significant investments in original content production.',
    image: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg',
    date: '2023-05-11T13:10:00Z',
    source: 'Entertainment Weekly',
    category: 'entertainment',
    url: '/article/5',
  },
  {
    id: '6',
    title: 'Advancements in AR Technology Transform Remote Collaboration',
    content: `<p>Augmented reality (AR) technology is revolutionizing how teams collaborate remotely, with new enterprise solutions offering immersive virtual workspaces that transcend traditional video conferencing limitations.</p>
    <p>These advanced AR platforms enable teams to manipulate 3D models in shared virtual spaces, annotate physical environments in real-time, and experience a sense of co-presence that approximates in-person collaboration.</p>
    <p>Early adopters report significant improvements in communication clarity, design iteration efficiency, and overall team engagement, particularly for complex projects involving spatial or physical components.</p>
    <p>As AR hardware becomes more accessible and software platforms more sophisticated, this technology is expected to become a standard component of remote and hybrid work environments across industries.</p>`,
    summary: 'New augmented reality solutions are transforming remote collaboration with immersive virtual workspaces.',
    image: 'https://images.pexels.com/photos/8728560/pexels-photo-8728560.jpeg',
    date: '2023-05-10T10:05:00Z',
    source: 'TechCrunch',
    category: 'technology',
    url: '/article/6',
  },
];

// Simulate API calls with promises and timeouts
export const fetchArticles = (categoryFilter?: string): Promise<Article[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const filteredArticles = categoryFilter
        ? articles.filter(article => article.category === categoryFilter)
        : articles;
      resolve(filteredArticles);
    }, 500);
  });
};

export const fetchArticleById = (id: string): Promise<Article | undefined> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const article = articles.find(article => article.id === id);
      resolve(article);
    }, 300);
  });
};

export const fetchCategories = (): Promise<Category[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(categories);
    }, 300);
  });
};

export const fetchFeedSources = (): Promise<FeedSource[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(feedSources);
    }, 300);
  });
};

export const searchArticles = (query: string): Promise<Article[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const searchResults = articles.filter(
        article => 
          article.title.toLowerCase().includes(query.toLowerCase()) || 
          article.content.toLowerCase().includes(query.toLowerCase())
      );
      resolve(searchResults);
    }, 500);
  });
};